package org.hl7.fhir.instance.model;

// Copyright HL7 (http://www.hl7.org). Generated on Mon, May 14, 2012 09:48+1000 for FHIR v0.01

/**
 * null
 */
public class Device extends Resource {


}

