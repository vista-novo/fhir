package org.hl7.fhir.instance.model;


public abstract class Structure extends Type {
	
	
	
}
