package org.hl7.fhir.instance.model;

public class Code extends Type {

	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
