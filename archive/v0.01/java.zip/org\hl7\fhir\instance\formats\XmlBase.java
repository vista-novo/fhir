package org.hl7.fhir.instance.formats;

public class XmlBase {
  protected static final String FHIR_NS = "http://www.hl7.org/fhir";

}
