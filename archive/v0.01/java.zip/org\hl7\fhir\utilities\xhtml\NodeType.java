package org.hl7.fhir.utilities.xhtml;

public enum NodeType { Element, Text, Comment, DocType, Document, Instruction }