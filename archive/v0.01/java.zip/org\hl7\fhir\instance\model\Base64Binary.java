package org.hl7.fhir.instance.model;

public class Base64Binary extends Type {

	private byte[] value;

	public byte[] getValue() {
		return value;
	}

	public void setValue(byte[] value) {
		this.value = value;
	}
	
	
	
}
