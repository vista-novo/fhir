package org.hl7.fhir.instance.model;

import java.net.URI;

public class Uri extends Type {
	
	private URI value;

	public URI getValue() {
		return value;
	}

	public void setValue(URI value) {
		this.value = value;
	}
	
	
	
	
}
