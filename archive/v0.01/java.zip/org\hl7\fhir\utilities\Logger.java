package org.hl7.fhir.utilities;

public interface Logger {
    public void log(String content);
}
