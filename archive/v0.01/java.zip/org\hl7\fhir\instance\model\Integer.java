/**
 * 
 */
package org.hl7.fhir.instance.model;

/**
 * @author Grahame
 *
 */
public class Integer extends Ordered {

	private int value;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	} 
	
	
}
