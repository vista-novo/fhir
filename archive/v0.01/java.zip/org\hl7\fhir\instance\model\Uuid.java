package org.hl7.fhir.instance.model;

public class Uuid extends Id {

	
}
