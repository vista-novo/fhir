package org.hl7.fhir.utilities.xhtml;

public class XhtmlDocument extends XhtmlNode {

  public XhtmlDocument() {
    super();
    setNodeType(NodeType.Document);
  }

}
