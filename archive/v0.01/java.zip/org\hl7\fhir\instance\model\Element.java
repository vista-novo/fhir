package org.hl7.fhir.instance.model;

public abstract class Element {

	private String xmlId;

	public String getXmlId() {
		return xmlId;
	}

	public void setXmlId(String xmlId) {
		this.xmlId = xmlId;
	}
	
	
}
