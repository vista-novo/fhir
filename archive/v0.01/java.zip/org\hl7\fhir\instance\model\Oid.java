package org.hl7.fhir.instance.model;

public class Oid extends Id {

	
}
