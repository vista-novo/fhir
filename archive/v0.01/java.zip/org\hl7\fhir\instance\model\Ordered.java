package org.hl7.fhir.instance.model;

/**
 * Can be a parameter of an interval 
 */
public class Ordered extends Type {

}
