/**
 * 
 */
package org.hl7.fhir.instance.model;

/**
 * @author Grahame
 *
 */
public class Boolean extends Type {

	private boolean value;

	public boolean getValue() {
		return value;
	}

	public void setValue(boolean value) {
		this.value = value;
	} 
	
	
}
