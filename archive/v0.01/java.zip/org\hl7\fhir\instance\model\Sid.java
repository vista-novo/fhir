package org.hl7.fhir.instance.model;

public class Sid extends Uri {
	
}
